"""
SnapSite - AI-Powered Website Generation Platform
Main FastAPI application entry point
"""
